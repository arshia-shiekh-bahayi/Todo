# Todo
**What is the project about?**

As you know the name of my project is Todo.
This project is designed with django and django_rest_framework and also HTML as the front-end part. 

In this project I tried to make a site that allow you to note down a list of your tasks and when you are finished you can change the status of task to **Done**.

It also contains an api part that you can simply use by requesting them with apps like post man and thunder client or even your browser.

You can see the document of api at /api-docs/.
